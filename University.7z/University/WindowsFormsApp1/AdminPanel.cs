﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class AdminPanel : Form
    {
        public AdminPanel()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            createUser();
        }

        public void createUser()
        {
            Random r = new Random();
            using (KayumovAEntities db = new KayumovAEntities())
            {
                Users user = new Users()
                {
                    user_id = newrand(),
                    Login = textBox1.Text,
                    Password = textBox2.Text,
                    Email = textBox3.Text,
                    Role = textBox4.Text,
                    Inititals = textBox5.Text,
                };

                db.Users.Add(user);
                db.SaveChanges();
                MessageBox.Show("Добавление пользователя прошло успешно! ID "+user.user_id);


            }
            int newrand()
            {
                return r.Next(50, 250);
            }

        }



        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.OpenForms[1].Show();
        }
    }
}
