﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Login : Form
    {
        Users user = new Users();
        public bool flag = false;
        public Login()
        {
            InitializeComponent();
            minusUser();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        public void login()
        {
            using (KayumovAEntities db = new KayumovAEntities())
            {

                foreach (var person in db.Users)
                {
                    void setup()
                    {
                        user.user_id = 0;
                        user.Login = person.Login;
                        user.Password = person.Password;
                        user.Role = person.Role;
                        user.Inititals = person.Inititals;
                        user.Email = person.Email;
                    }
                    if (textBox1.Text == person.Login && textBox2.Text == person.Password)
                    {
                        setup();
                        minusUser();
                        try
                        {
                            db.Users.Add(user);
                        }
                        catch
                        {
                        }
                        flag = true;
                    }
                   
                }

                if (!flag)
                {
                    MessageBox.Show("Данные пользователя были введены неверно!\nПопробуйте снова.");
                    flag = false;
                    textBox1.Text = null;
                    textBox2.Text = null;
                }
                db.SaveChanges();

            }
        }

        //Добавляем псевдопользователя для удобства использования авторизированного пользователя
        public void minusUser()
        {
            using (KayumovAEntities db = new KayumovAEntities())
            {
                foreach(var person in db.Users)
                {
                    if (person.user_id == 0)
                    {
                        db.Users.Remove(person);
                    }
                }
                db.SaveChanges();
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            login();
            if (flag)
            {
                this.Hide();
                Form mp = new MainPage();
                mp.Show();
            }
            //Application.OpenForms[1].Close();
        }
    }
}
