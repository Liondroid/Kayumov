﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class MainPage : Form
    {
        Users user = new Users();
        public MainPage()
        {
            InitializeComponent();
            loadprofile();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            loadprofile();
        }

        public void loadprofile()
        {
            using(KayumovAEntities db = new KayumovAEntities())
            {
                foreach(var person in db.Users)
                {
                    if (person.user_id == 0)
                    {
                        label1.Text = "Логин " + person.Login;
                        label2.Text = "Роль " + person.Role;
                        label3.Text = "e-mail " + person.Email;
                        if (person.Role == "Администратор")
                        {
                            button4.Visible = true;
                        }
                    }
                }
                
            }
        }

        public void logout()
        {
            using (KayumovAEntities db = new KayumovAEntities())
            {
                foreach (var person in db.Users)
                {
                    if (person.user_id == 0)
                    {
                        db.Users.Remove(person);
                    }
                }
                db.SaveChanges();
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            logout();
            this.Close();
            Application.OpenForms[0].Show();       
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using(KayumovAEntities db = new KayumovAEntities())
            {
                foreach (var person in db.Users)
                {
                    if (person.user_id == 0)
                    {
                        foreach (var per in db.Users)
                        {
                            if (person.Login == per.Login)
                            {
                                user = per;
                                per.Login = textBox1.Text;
                                per.Password = textBox2.Text;
                                per.Email = textBox3.Text;
                            }
                        }
                    }
                }
                db.SaveChanges();
                MessageBox.Show($"Изменение данных прошло успешно!\nЛогин {textBox1.Text}\nПароль {textBox2.Text}\nЭлектронная почта {textBox3.Text}\n"); 
            }
            button2.Visible = false;
            button5.Visible = false;
            button3.Text = "Изменить";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            button5.Visible = true;
            button2.Visible = true;
            button3.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = "login";
            textBox1.Text="password";
            textBox1.Text="email";
            textBox1.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            button5.Visible = false;
            button2.Visible=false;
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form ap = new AdminPanel();
            ap.Show();
        }
    }
}
